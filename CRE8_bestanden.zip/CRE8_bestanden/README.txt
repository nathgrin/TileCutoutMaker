Er zijn drie folders:
- De bestanden voor cutouts op 50x70cm papier zijn in principe te vinden in de folder svg/
- De folder png/ bevat dezelfde bestanden als svg/ maar dan in .png formaat, voor als de svg bestanden niet werken.
- In de filder tiles/ zijn enkele svg bestanden opgenomen van losse tekeningen.

Deze folder is ook te vinden via https://github.com/nathgrin/TileCutoutMaker/tree/main/CRE8_bestanden

De onderlinge verhoudingen zijn belangrijk.

Bestelling, in alfabetische volgorde: (totaal 50x)
EinsteinHat.svg 4x
EinsteinSpectre.svg 4x
PenroseQuadDart.svg 2x
PenroseQuadKite.svg 4x
PenroseRhombiFat.svg 4x
PenroseRhombiSlim.svg 2x
poly_3.svg 3x
poly_4.svg 3x
poly_5.svg 3x
poly_6.svg 3x
poly_7.svg 3x
poly_8.svg 3x
poly_9.svg 3x
poly_10.svg 3x
poly_11.svg 3x
poly_12.svg 3x